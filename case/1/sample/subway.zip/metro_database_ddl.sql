CREATE DATABASE `metro` /*!40100 DEFAULT CHARACTER SET utf8 */;
CREATE TABLE `line_info` (
  `line_no` int(11) NOT NULL,
  `station_no` int(11) NOT NULL,
  `station_name` varchar(128) NOT NULL,
  PRIMARY KEY (`station_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='지하철 역 정보';

CREATE TABLE `on_off_info` (
  `onoff_dt` date NOT NULL,
  `station_no` int(11) NOT NULL,
  `onoff` int(11) NOT NULL COMMENT '승차: 1\\\\n하차: 0',
  `onoff_tm` int(11) NOT NULL COMMENT '시간대\n     ~ 06: 5\n06 ~ 07: 6\n07 ~ 08: 7\n08 ~ 09: 8\n...\n22 ~ 23: 22\n23 ~ 24: 23\n24 ~     : 24',
  `passengers_cnt` int(11) NOT NULL,
  PRIMARY KEY (`onoff_dt`,`station_no`,`onoff_tm`,`onoff`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='일별, 시간별, 역 승하차 정보';